Procedure :
Installation Procedure :
sudo apt-get install python3-pip

sudo pip3 install virtualenv
virtualenv venv
source venv/bin/activate

pip install -r requirements.txt
pip install djangorestframework

python3 manage.py runserver

access:
http://127.0.0.1:8000

database admin credential:.
http://127.0.0.1:8000/admin
myuserssd
SSD1sh1dd3n@m0dule-

# Groups created in server are:
    # complainant (ticket system user);
    # Officer (police officer)
    # Officer_Supv (supervisor with additional permissions)

# Users created in server are:
    # user1 - (Complainant group)
    # user2 - (Complainant group)
    # EddyJanko - (Officer)
    # JamieRegan - (Officer_supv)
    # Admin - (superuser)

#File sharing:
    #Admin users can access the media folder for the files. 