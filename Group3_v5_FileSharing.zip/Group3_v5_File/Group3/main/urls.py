from django.urls import path
from .views import TicketListView, TicketDetailView, TicketCreateView, TicketDeleteView
from . import views

urlpatterns = [
path("", views.home, name="home"),
#path("", TicketListView.as_view(), name="home"),
path("view/", views.view, name="index"),
path("home/", views.home, name="home"),
#path("home/", TicketListView.as_view(), name="home"),
path("ticket/<int:pk>/", TicketDetailView.as_view(), name="ticket-detail"),
path("ticket/new/", TicketCreateView.as_view(), name="ticket-create"),
path("ticket/<int:pk>/delete", TicketDeleteView.as_view(), name="ticket-delete"),
path("upload", views.upload, name="upload"),
]

