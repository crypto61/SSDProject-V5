from django.shortcuts import render
from django.contrib.auth.mixins import UserPassesTestMixin
from django.views.generic import ListView, DetailView, CreateView, DeleteView
from users.models import Ticket
from django.conf import settings
from django.core.files.storage import FileSystemStorage


# Create your views here.
def home(request):
	if request.user.is_authenticated:
		context = {
			'tickets': Ticket.objects.filter(user_id=request.user)
		}
		return render(request, "main/home.html", context)

	else:
		return render(request, "main/home.html", {})

def upload(request):
    if request.method == 'POST' and request.FILES['upload']:
        upload = request.FILES['upload']
        fss = FileSystemStorage()
        file = fss.save(upload.name, upload)
        file_url = fss.url(file)
        return render(request, 'main/upload.html', {'file_url': file_url})
    return render(request, 'main/upload.html')

class TicketListView(ListView):
	model = Ticket
	template_name = 'main/home.html'
	context_object_name = 'tickets'
	ordering = ['-date_posted']

class TicketDetailView(UserPassesTestMixin, DetailView):
	model = Ticket
	template_name = 'main/ticket_detail.html'

	def test_func(self):
		ticket = self.get_object()
		if self.request.user == ticket.user_id:
			return True
		return False

class TicketCreateView(CreateView):
	model = Ticket
	template_name = 'main/ticket_form.html'
	fields = ['ticketID','complain','email','emergency']

	def form_valid(self, form):
		form.instance.user_id = self.request.user
		return super().form_valid(form)

class TicketDeleteView(UserPassesTestMixin, DeleteView):
	model = Ticket
	template_name = 'main/ticket_confirm_delete.html'
	success_url = '/'

	def test_func(self):
		ticket = self.get_object()
		if self.request.user == ticket.user_id:
			return True
		return False

def view(request):
	return render(request, "main/home.html", {})
