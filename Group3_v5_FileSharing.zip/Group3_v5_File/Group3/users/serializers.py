
from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Ticket

class TicketSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ticket
        fields = ('subject', 'ticket', 'date_posted', 'email', 'username')
