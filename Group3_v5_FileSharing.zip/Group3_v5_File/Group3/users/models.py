from django.db import models
from django.db.models import Count
from django.utils import timezone
from django.contrib.auth.models import User
from django.conf import settings
from django.urls import reverse

"""

Created ticket model

ticketID: Integerfield
complain: TextField, No character limit
date_time: Defaults to current time when ticket is submitted. 
Email: Character field
Emergency: Defaults to false if not changed
UserID: Related to a user object with foreign key



	# IF character limit needed for the complaint, refer to the line below
	#complain = models.CharField(max_length=50) # Limiting 50 characters

"""

class Ticket(models.Model):
	ticketID = models.CharField(max_length=50)  
	complain = models.TextField() 
	date_posted = models.DateTimeField(default=timezone.now)
	email = models.CharField(max_length=50)
	emergency = models.BooleanField(default=False)
	user_id = models.ForeignKey(User, on_delete=models.CASCADE)

	class Meta:
		ordering = ['date_posted']  
		
	def __str__(self):
		return 'Ticket {}  created by {}'.format(self.ticketID, self.user_id) 

	def get_absolute_url(self):
		return reverse('ticket-detail', kwargs={'pk':self.pk})

# Create your models here.
