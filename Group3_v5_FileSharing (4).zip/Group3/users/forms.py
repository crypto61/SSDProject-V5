from django import forms
from .models import Ticket
from django import forms

#DataFlair
class TicketCreate(forms.ModelForm):
    class Meta:
        model = Ticket
        fields = '__all__'

