from django.shortcuts import render
from django.shortcuts import render, redirect, get_object_or_404
from rest_framework import generics
from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import Ticket
from .serializers import TicketSerializer
from rest_framework.views import APIView


# Create your views here.

class TicketView(APIView):
	def get(self, request, format=None):
		print(request.user)
		orgs = Ticket.objects.filter(user_id=request.user)
		serializer = TicketSerializer(orgs, many=True)
		return Response(serializer.data)



