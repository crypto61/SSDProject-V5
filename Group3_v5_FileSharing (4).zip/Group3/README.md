To get the project up and running :

requirements : python 3.9.7 for windows and python 3.6.9 for linux

1.Installation of pip and virtual environment
-Linux:
sudo apt-get install python3-pip
sudo pip3 install virtualenv
virtualenv venv
source venv/bin/activate

-Windows:
curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
python get-pip.py
pip install virtualenv
python -m virtualenv venv
.\venv\Scripts\activate

2. please run the following commands : 
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py test # Run the standard tests. These should all pass.
python manage.py runserver



********
database admin superuser credential:.
http://127.0.0.1:8000/admin
http://127.0.0.1:8000/cms
myuserssd
SSD1sh1dd3n@m0dule-
********
