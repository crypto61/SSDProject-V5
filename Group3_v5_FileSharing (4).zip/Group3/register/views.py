from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from .forms import RegisterForm
"""
the register page function allows to check if a POST form request
is existing, in this case we check the validity of user's 
form and we save the user informations.
"""
def register(response):
	if response.method == "POST":
		form = RegisterForm(response.POST)
		if form.is_valid():
			form.save()
			return redirect("/home")
	else:
		form = RegisterForm()
		
	return render(response, "register/register.html", {"form":form})