from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
"""this class aims to create a form concerning the user login, then there is password 1 and 2, because it allows to check if the 2 password correspond.
the fields is the layout on register.html page"""
class RegisterForm(UserCreationForm):
	class Meta:
		model = User
		fields = ["username","email","first_name","last_name", "password1", "password2"]
